<?php
class ControllerExtensionModuleCrawler extends Controller {
	private $error = array();

	public function index() {
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');



		$this->response->setOutput($this->load->view('extension/module/crawler', $data));
	}

	public function crawler() {
		// Assoc array of data
		$productData = array(
			'product_description' => array(
				2 => array(
					'name' => 'Product Name Here',
					'meta_title' => 'Product Name Here',
					'meta_description' => 'Product Name Here',
					'meta_keyword' => 'Product Name Here',
					'description' => 'Product Name Here',
					'featured' => 'Product Name Here'
				)
			),
			'price' => 0,
			'model' => 'ABC123',
			'quantity' => 100,
			'image' => '',
			'status' => 1,
			'sort_order' => 1,
			'manufacturer_id' => 0
		);

		// Load model into memory if it isn't already
		$this->load->model('catalog/product');
		//$this->load->model('extension/module/crawler');

		// Attempt to pass the assoc array to the add Product method
		$product_id = $this->model_catalog_product->addProduct($this->request->post);
		//$product_id = $this->model_catalog_product->addProduct($productData);
		return $product_id;
	}
	
	
}