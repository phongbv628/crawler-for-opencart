


2. admin/controller/common/column_left.php

if ($this->user->hasPermission('access', 'extension/module/crawler')) {
				$marketplace[] = array(
					'name'	   => 'Crawler',
					'href'     => $this->url->link('extension/module/crawler', 'user_token=' . $this->session->data['user_token'], true),
					'children' => array()		
				);
			}